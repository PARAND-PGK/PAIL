"""
تنظیمات کلی پروژه PAIL
مقادیر از فایل .env خوانده می‌شوند.
"""
import os
from dotenv import load_dotenv

load_dotenv()

# توکن ربات تلگرام (اجباری)
BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")

# مسیر فایل دیتابیس SQLite
DB_PATH: str = os.getenv("DB_PATH", "database/pail.db")

# مسیر پوشه ذخیره‌سازی فایل‌های پیوست
STORAGE_PATH: str = os.getenv("STORAGE_PATH", "storage/attachments")

# دامنه ثابت آدرس‌های PAIL (فقط داخلی و شبیه‌سازی‌شده - نه ایمیل واقعی)
ADDRESS_DOMAIN: str = "@pail.com"
